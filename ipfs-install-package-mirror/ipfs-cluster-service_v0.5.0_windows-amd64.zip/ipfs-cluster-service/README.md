# `ipfs-cluster-service`

> The IPFS cluster peer daemon

`ipfs-cluster-service` runs a full IPFS Cluster peer.

### Usage

Usage information can be obtained with:

```
$ ipfs-cluster-service --help
```

For more information, please check the [Documentation](https://cluster.ipfs.io/documentation), in particular the [`ipfs-cluster-service` section](https://cluster.ipfs.io/documentation/ipfs-cluster-service).
